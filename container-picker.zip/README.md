# Container Picker

## How to Run

```bash
mvn spring-boot:run
```

## API Endpoint

POST `/pickSpot`

### Sample Request

```json
{
  "container": {
    "id": "C1",
    "size": "small",
    "needsCold": false,
    "x": 1,
    "y": 1
  },
  "yardMap": [
    { "x": 1, "y": 2, "sizeCap": "small", "hasColdUnit": false, "occupied": false },
    { "x": 2, "y": 2, "sizeCap": "big", "hasColdUnit": true, "occupied": false }
  ]
}
```

### Sample Response

```json
{
  "container": {
    "containerId": "C1",
    "targetX": 1,
    "targetY": 2
  }
}
```

---
