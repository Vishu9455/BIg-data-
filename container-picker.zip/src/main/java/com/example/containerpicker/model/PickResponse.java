package com.example.containerpicker.model;

import java.util.Optional;

public class PickResponse {
    private Optional<BestSlot> container;
    private Optional<String> error;

    public PickResponse(BestSlot container) {
        this.container = Optional.of(container);
        this.error = Optional.empty();
    }

    public PickResponse(String error) {
        this.container = Optional.empty();
        this.error = Optional.of(error);
    }

    public Optional<BestSlot> getContainer() { return container; }
    public Optional<String> getError() { return error; }

    public static class BestSlot {
        private String containerId;
        private int targetX;
        private int targetY;

        public BestSlot(String containerId, int targetX, int targetY) {
            this.containerId = containerId;
            this.targetX = targetX;
            this.targetY = targetY;
        }

        public String getContainerId() { return containerId; }
        public int getTargetX() { return targetX; }
        public int getTargetY() { return targetY; }
    }
}
