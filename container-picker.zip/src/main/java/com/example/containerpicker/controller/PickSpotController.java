package com.example.containerpicker.controller;

import com.example.containerpicker.model.PickRequest;
import com.example.containerpicker.model.PickResponse;
import com.example.containerpicker.service.SpotPickerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/")
public class PickSpotController {

    private final SpotPickerService service = new SpotPickerService();

    @PostMapping("/pickSpot")
    public ResponseEntity<?> pickSpot(@RequestBody PickRequest request) {
        if (request.getContainer() == null || request.getYardMap() == null) {
            return ResponseEntity.badRequest().body("Invalid request: Missing container or yardMap.");
        }
        return ResponseEntity.ok(service.pickBestSpot(request));
    }
}
