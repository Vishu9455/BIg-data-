package com.example.containerpicker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContainerPickerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ContainerPickerApplication.class, args);
    }
}
