package com.example.containerpicker.service;

import com.example.containerpicker.model.*;

public class SpotPickerService {
    private static final int INVALID = 10_000;

    public PickResponse pickBestSpot(PickRequest request) {
        Container container = request.getContainer();
        int bestScore = Integer.MAX_VALUE;
        YardSlot bestSlot = null;

        for (YardSlot slot : request.getYardMap()) {
            int score = calculateScore(container, slot);
            if (score < bestScore) {
                bestScore = score;
                bestSlot = slot;
            }
        }

        if (bestSlot == null || bestScore >= INVALID) {
            return new PickResponse("no suitable slot");
        } else {
            return new PickResponse(new PickResponse.BestSlot(container.getId(), bestSlot.getX(), bestSlot.getY()));
        }
    }

    private int calculateScore(Container c, YardSlot s) {
        int distance = Math.abs(c.getX() - s.getX()) + Math.abs(c.getY() - s.getY());
        int sizePenalty = ("big".equals(c.getSize()) && "small".equals(s.getSizeCap())) ? INVALID : 0;
        int coldPenalty = (c.isNeedsCold() && !s.isHasColdUnit()) ? INVALID : 0;
        int occupiedPenalty = s.isOccupied() ? INVALID : 0;
        return distance + sizePenalty + coldPenalty + occupiedPenalty;
    }
}
